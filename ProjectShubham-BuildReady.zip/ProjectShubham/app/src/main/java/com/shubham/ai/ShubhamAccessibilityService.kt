package com.shubham.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ShubhamAccessibilityService : AccessibilityService() {
    companion object {
        var instance: ShubhamAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // V1 foundation: later versions will add safe UI discovery,
        // text input, clicking, scrolling and multi-step task execution.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
