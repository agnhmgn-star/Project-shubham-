package com.shubham.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val requestCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = "SHUBHAM"
            textSize = 34f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "मैं तैयार हूँ। नीचे बोलकर command दें।"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 40)
        }
        val mic = Button(this).apply {
            text = "🎙️ Shubham से बोलें"
            setOnClickListener { listen() }
        }
        val accessibility = Button(this).apply {
            text = "Device Control चालू करें"
            setOnClickListener {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        layout.addView(title)
        layout.addView(status)
        layout.addView(mic)
        layout.addView(accessibility)
        setContentView(layout)

        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA),
            requestCode
        )
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Shubham को command दें")
        }
        startActivityForResult(intent, 200)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 200 || resultCode != Activity.RESULT_OK) return
        val command = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        status.text = "आप: $command"
        executeCommand(command.lowercase(Locale.getDefault()))
    }

    private fun executeCommand(command: String) {
        when {
            command.contains("chrome") -> openUrl("https://www.google.com")
            command.contains("google") || command.contains("खोज") || command.contains("सर्च") -> {
                val q = command.replace(Regex("google|पर|खोजो|खोज|सर्च करो|सर्च"), " ").trim()
                openUrl("https://www.google.com/search?q=" + Uri.encode(q.ifBlank { "भारत की आज की खबरें" }))
            }
            command.contains("youtube") -> openUrl("https://www.youtube.com")
            command.contains("camera") || command.contains("कैमरा") -> {
                startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            }
            command.contains("phone") || command.contains("फोन") || command.contains("dialer") -> {
                startActivity(Intent(Intent.ACTION_DIAL))
            }
            command.contains("settings") || command.contains("सेटिंग") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }
            command.contains("back") || command.contains("वापस") -> {
                ShubhamAccessibilityService.instance?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                )
            }
            command.contains("home") || command.contains("होम") -> {
                ShubhamAccessibilityService.instance?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
                )
            }
            else -> {
                speak("मैंने command सुनी: $command. इस command के लिए अगला AI action module अभी जोड़ा जाएगा।")
            }
        }
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun speak(text: String) {
        status.text = text
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "shubham")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
