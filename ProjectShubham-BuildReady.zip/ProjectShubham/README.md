# Project Shubham — Android Core V1

Shubham is a personal Android AI-agent project.

## Current V1
- Hindi voice command input
- Hindi text-to-speech
- Google/Chrome/YouTube opening
- Google search
- Camera intent
- Dialer
- Settings
- Home/Back through Accessibility Service
- Permission and device-control foundation

## Next milestones
1. Connect an LLM/AI backend.
2. Add structured tool/function calling.
3. Add web research: search -> open -> extract -> summarize.
4. Add safe app/UI control through Accessibility APIs.
5. Add contacts/calling/messaging workflows with confirmation.
6. Add memory and a wake-word/hands-free mode.

## Important
Android does not allow unrestricted control of every app. Shubham must operate within Android permissions, app APIs, user-granted accessibility capabilities and other platform security rules.
