#!/bin/sh
set -e
if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  echo "Gradle wrapper JAR is missing. Open this project once in Android Studio and use Gradle > wrapper,"
  echo "or run with a system Gradle installation to generate the wrapper JAR."
  exit 1
fi
./gradlew :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
